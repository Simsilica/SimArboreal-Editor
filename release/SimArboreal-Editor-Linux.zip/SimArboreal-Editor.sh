#!/bin/sh
java  -jar SimArboreal-Editor.jar
        